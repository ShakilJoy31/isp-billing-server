const allowedOrigins = [
  "http://localhost:3000",
  "http://localhost:3001",
  "https://admin.billisp.com",
  "http://admin.billisp.com",
  "https://www.admin.billisp.com",
  "http://www.admin.billisp.com"
];

module.exports = allowedOrigins;
